#include<stdio.h>
#include<conio.h>

int main() 
{
    for (int i = 1; i <= 50; i++)
    {
        printf("\n %d", i);
    }

    return 0;
}
